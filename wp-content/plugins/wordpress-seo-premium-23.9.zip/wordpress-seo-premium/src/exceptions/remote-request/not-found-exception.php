<?php

namespace Yoast\WP\SEO\Premium\Exceptions\Remote_Request;

/**
 * Class to manage a 404 - not found response.
 */
class Not_Found_Exception extends Remote_Request_Exception {

}
